# GPT-2 Text Generation Fine-Tuning

This repository contains code to fine-tune OpenAI's GPT-2 on a custom text dataset.

## Requirements

- transformers
- torch
- datasets

Install them via:

```bash
pip install transformers datasets torch
```

## How to Use

1. Replace `your_dataset.txt` with your actual text dataset.
2. Run the training script:

```bash
python train_gpt2.py
```

The fine-tuned model will be saved in the `gpt2-finetuned/` directory.
