# Neural Style Transfer

This project demonstrates how to apply the artistic style of one image to the content of another using neural style transfer in PyTorch.

## Requirements

- torch
- torchvision
- pillow

Install them using:

```bash
pip install torch torchvision pillow
```

## Usage

1. Replace `content.jpg` and `style.jpg` with your own images.
2. Run the script:

```bash
python style_transfer.py
```

The stylized image will be saved as `stylized_output.jpg`.
