# Image Generation with Pre-trained Models

This project demonstrates how to use pre-trained generative models like Stable Diffusion to generate images from text prompts.

## Requirements

- diffusers
- torch
- transformers
- accelerate

Install them with:

```bash
pip install diffusers transformers torch accelerate
```

## Usage

Run the script:

```bash
python generate_image.py
```

Replace the prompt in the script to generate different images.

The output image will be saved as `generated_image.png`.
